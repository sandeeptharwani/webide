# OpenWeatherSample
WebIDE Ninja #1: sample app 

This repository is the source code for part 1 of How to become a WebIDE ninja developer series. 
the full blog post can be found here: http://scn.sap.com/community/developer-center/front-end/blog/2016/01/17/webide-how-to-consume-3-party-services-in-ui5-app
